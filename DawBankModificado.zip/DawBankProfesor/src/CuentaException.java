public class CuentaException extends Exception {
    public CuentaException(String mensaje) {
        super(mensaje);
    }
}
