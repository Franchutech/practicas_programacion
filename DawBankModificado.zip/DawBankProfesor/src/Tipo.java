public enum Tipo {
    INGRESO, RETIRADA
}
