public enum Genero {
    DRAMA,
    COMEDIA,
    ACCION,
    CIENCIA_FICCION,
    ROMANCE,
    ANIMACION,
    DOCUMENTALES,
}
